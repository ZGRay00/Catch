// Task/concurrency UI regression: a local page, synthetic saves and blocked HTTP(S).
// Does not run game controls, use an account or visit the online game.
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),net=require('node:net'),assert=require('node:assert/strict');
const {spawn}=require('node:child_process'),{pathToFileURL}=require('node:url');
const H=require('../Pokecatch自动助手.user.js'),original=fs.readFileSync(path.join(__dirname,'../Pokecatch自动助手.user.js'),'utf8');
const source=original.replace('    mount();','    window.__pcExecutionTest={engine};\n    mount();');
assert.notEqual(source,original,'Review the isolated test export hook');
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const game={trainer:{id:'execution-ui-browser'},money:1000,mons:[{uid:'a',id:6,level:70,reg:'kanto'}],team:['a'],road:['a'],dex:{},stats:{},items:{},travel:{to:['johto','hoenn','sinnoh']},pension:{mons:[],eggs:[]},under:{slots:[],sent:0,used:{}},adv:{layout:6,chapter:0,unlocked:65,node:0,runs:0,speed:4,badges:['Maître','Forêt'],loops:[],gifts:{},deaths:{}}};
async function main(){
    assert.equal(typeof H.taskExecutionState,'function','Wait for the completed execution model');
    const dir=fs.mkdtempSync(path.join(os.tmpdir(),'pokecatch-execution-ui-browser-'));
    const chrome=process.env.CHROME_PATH||['C:/Program Files/Google/Chrome/Application/chrome.exe','C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'].find(fs.existsSync);assert.ok(chrome);
    const server=net.createServer();await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const port=server.address().port;await new Promise(resolve=>server.close(resolve));
    const child=spawn(chrome,['--headless=new','--disable-gpu','--no-first-run',`--remote-debugging-port=${port}`,`--user-data-dir=${path.join(dir,'profile')}`,'about:blank'],{windowsHide:true,stdio:'ignore'});
    let socket,send;const checks=[];
    try{
        let pages;for(let n=0;n<80;n++){try{pages=await(await fetch(`http://127.0.0.1:${port}/json/list`)).json();if(pages.length)break;}catch{}await delay(100);}assert.ok(pages?.length);
        socket=new WebSocket(pages.find(page=>page.type==='page').webSocketDebuggerUrl);await new Promise((resolve,reject)=>{socket.onopen=resolve;socket.onerror=reject;});
        let seq=0;const pending=new Map();socket.onmessage=event=>{const message=JSON.parse(event.data),call=pending.get(message.id);if(!call)return;pending.delete(message.id);clearTimeout(call.timer);message.error?call.reject(Error(message.error.message)):call.resolve(message.result);};
        send=(method,params={})=>new Promise((resolve,reject)=>{const id=++seq,timer=setTimeout(()=>{pending.delete(id);reject(Error(method+' timed out'));},15000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}));});
        const evaluate=async expression=>{const result=await send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(result.exceptionDetails)throw Error(result.exceptionDetails.exception?.description||result.exceptionDetails.text);return result.result.value;};
        await send('Page.enable');await send('Runtime.enable');await send('Network.enable');await send('Network.setBlockedURLs',{urls:['http://*','https://*']});
        await send('Emulation.setDeviceMetricsOverride',{width:1280,height:900,deviceScaleFactor:1,mobile:false});
        const setup=`localStorage.clear();window.fixtureState=${JSON.stringify(game)};localStorage.setItem('gachamon-save-v1',JSON.stringify(fixtureState));localStorage.setItem('pokecatch-helper:v1:'+fixtureState.trainer.id,JSON.stringify({settings:{spendBudget:20000}}));localStorage.setItem('pokecatch-tab','execution-ui-tab');window.GM_registerMenuCommand=()=>{};window.commitExecution=()=>{localStorage.setItem('gachamon-save-v1',JSON.stringify(fixtureState));__pcExecutionTest.engine.onChange()};`;
        const html=path.join(dir,'index.html');fs.writeFileSync(html,'<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><body><script>'+setup+'</script><script>'+source.replace(/<\/script/gi,'<\\/script')+'</script></body>');
        await send('Page.navigate',{url:pathToFileURL(html).href});for(let n=0;n<80&&!await evaluate('!!window.__pokecatchHelper?.ready');n++)await delay(50);assert.equal(await evaluate('!!window.__pokecatchHelper?.ready'),true);
        const root="document.querySelector('#pokecatch-auto-helper').shadowRoot";
        assert.deepEqual(await evaluate('[__pcExecutionTest.engine.settings.spendBudget,__pcExecutionTest.engine.settings.autoPurchase]'),[20000,true]);
        checks.push('a pre-switch account with a saved positive procurement budget retains that authorization');
        const panes=await evaluate(`(()=>{const r=${root},e=__pcExecutionTest.engine;const views=[];
            for(const key of ['tasks','dex','weather','settings','activity']){
                r.querySelector('[data-workspace="'+key+'"]').click();
                views.push([...r.querySelectorAll('[id^=pane-]')].filter(el=>el.getClientRects().length).map(el=>el.id));
                if(!r.querySelector('.commandbar #start').getClientRects().length||e.running)throw Error('Workspace changed execution');
            }
            return views})()`);
        assert.deepEqual(panes,[['pane-tasks'],['pane-dex'],['pane-weather'],['pane-settings'],['pane-activity']]);checks.push('workspace navigation exposes one page at a time with task commands available');
        const calendar=await evaluate(`(()=>{
            const e=__pcExecutionTest.engine,r=${root},panel=r.querySelector('#season-calendar'),clock=Date.now;
            const read=()=>({key:panel.dataset.season,name:panel.querySelector('strong').textContent,
                remaining:panel.querySelector('.season-remaining').textContent,end:Date.parse(panel.querySelector('time:last-of-type').dateTime)});
            const before=read();panel.open=true;
            try{
                Date.now=()=>before.end-1;e.onChange();const last=read();
                Date.now=()=>before.end;e.onChange();return {before,last,after:read(),open:panel.open,cycle:panel.querySelector('.season-next').textContent};
            }finally{Date.now=clock;panel.open=false;e.onChange();}
        })()`);
        assert.equal(calendar.last.name,calendar.before.name);assert.match(calendar.last.remaining,/1分钟/);
        assert.notEqual(calendar.before.key,calendar.after.key);assert.ok(calendar.after.end>calendar.before.end);
        assert.ok(calendar.open);assert.match(calendar.cycle,/3 个日历日.*12 天/);
        checks.push('the visible season, local changeover and countdown roll over at midnight while the disclosure stays open');
        const seasonalDex=await evaluate(`(()=>{
            const r=${root},input=r.querySelector('#dex-search'),results=r.querySelector('#dex-results');
            const lookup=id=>{input.value=id;input.dispatchEvent(new Event('input',{bubbles:true}));};
            const originalSeasons=fixtureState.seasons;
            try{
                fixtureState.seasons={585:['spring','winter']};commitExecution();r.querySelector('[data-workspace="dex"]').click();
                lookup('#585');const forms=[...results.querySelectorAll('.season-forms li')].map(el=>[el.dataset.seen,el.textContent]);
                lookup('#522');return {forms,summer:results.textContent,otherForms:!!results.querySelector('.season-forms')};
            }finally{
                fixtureState.seasons=originalSeasons;lookup('');r.querySelector('[data-workspace="activity"]').click();r.querySelector('[data-tab="maps"]').click();commitExecution();
            }
        })()`);
        assert.equal(seasonalDex.forms.length,4);assert.equal(seasonalDex.forms.filter(([seen])=>seen==='true').length,2);
        assert.equal(seasonalDex.forms.filter(([,label])=>label.includes('本季')).length,1);
        assert.equal(seasonalDex.otherForms,false);assert.match(seasonalDex.summer,/夏季限定/);
        checks.push('the dex distinguishes a summer-only encounter source from four separately tracked seasonal sightings');
        const expedition=await evaluate(`(()=>{
            const r=${root},e=__pcExecutionTest.engine,selector='[data-setting="underAutoStart"]';
            const task=r.querySelector('#pane-tasks '+selector),settings=r.querySelector('#pane-settings '+selector);
            const before=task.checked&&settings.checked;
            settings.click();
            const manual=[...r.querySelectorAll('[data-under-manual]')].every(el=>!el.classList.contains('hidden'));
            const limit=r.querySelector('#pane-tasks [data-setting="underFrom"]');
            limit.value='50';limit.dispatchEvent(new Event('change',{bubbles:true}));
            const value=r.querySelector('#pane-settings [data-setting="underFrom"]').value;
            task.click();e.onChange();
            return {before,manual,value,restored:settings.checked&&[...r.querySelectorAll('[data-under-manual]')].every(el=>el.classList.contains('hidden')),buddyVisible:!r.querySelector('[data-setting="trainBuddy"]').closest('details')};
        })()`);
        assert.deepEqual(expedition,{before:true,manual:true,value:'50',restored:true,buddyVisible:true});checks.push('underground task and background settings share the highest-start toggle and manual ceiling; the training companion has a distinct setting');
        const raidNote=await evaluate(`(()=>{
            const r=${root},e=__pcExecutionTest.engine;
            e.raidCheckNote='已按设置跳过拥有的异色目标';
            r.querySelector('[data-workspace="settings"]').click();
            const note=r.querySelector('#raid-check');
            const result={visible:!!note.getClientRects().length,text:note.textContent};
            e.raidCheckNote='';r.querySelector('[data-workspace="activity"]').click();return result;
        })()`);
        assert.equal(raidNote.visible,true);assert.match(raidNote.text,/已按设置跳过拥有的异色目标/);checks.push('the daily raid setting explains why the most recent check skipped the target');
        const raidDone=await evaluate(`(()=>{
            const r=${root},e=__pcExecutionTest.engine,previous=fixtureState.raids;
            const day=new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Paris'}).format(new Date());
            try{
                fixtureState.raids={seen:day,done:{['kanto|'+day]:1},doneBoss:{['kanto|'+day]:35}};
                commitExecution();r.querySelector('[data-workspace="settings"]').click();
                return {text:r.querySelector('#raid-check').textContent,running:e.running};
            }finally{fixtureState.raids=previous;commitExecution();r.querySelector('[data-workspace="activity"]').click();}
        })()`);
        assert.equal(raidDone.running,false);assert.match(raidDone.text,/已完成.*下次刷新.+月.+日 \d{2}:\d{2}（本地时间）/);
        checks.push('the idle settings panel shows the next local refresh for a completed Paris raid without starting a task');
        const preparationRanking=await evaluate(`(async()=>{
            const e=__pcExecutionTest.engine,r=${root},s=fixtureState,initial=s.adv;
            const previousSettings=e.settings,initialLevel=s.mons[0].level;
            const speedOptions=Array.from(r.querySelector('[data-setting="speed"]').options,el=>Number(el.value));
            s.adv={...initial,chapter:1,unlocked:3};s.mons[0].level=28;
            e.settings={...e.settings,mode:'progress',region:'current'};
            e.preparation={phase:'train',context:{kind:'progress',reg:'kanto',label:'主线'},targets:[],uids:['a'],route:{key:'1',name:'蓝色徽章',members:[1]},avoid:{}};
            commitExecution();
            const waitUntil=async text=>{for(let i=0;i<100&&!r.querySelector('#view').textContent.includes(text);i++){await new Promise(resolve=>setTimeout(resolve,30));e.onChange();}};
            await waitUntil('EXP/分钟');
            const comparing=r.querySelector('#view').textContent,shown=r.querySelector('#view tr.active')?.textContent;
            s.adv.chapter=0;commitExecution();
            await waitUntil('下一图蓝色徽章');
            const atStart=r.querySelector('#view').textContent;
            e.preparation=null;s.adv=initial;s.mons[0].level=initialLevel;e.settings=previousSettings;commitExecution();
            return {speedOptions,comparing,shown,atStart};
        })()`);
        assert.deepEqual(preparationRanking.speedOptions,[1,4]);assert.match(preparationRanking.comparing,/按补练阵容.*蓝色徽章.*上一图.*灰色徽章/);
        assert.match(preparationRanking.atStart,/下一图蓝色徽章.*超过 15%/);
        assert.match(preparationRanking.comparing,/EXP\/分钟/);assert.match(preparationRanking.shown,/蓝色徽章/);checks.push('mainline preparation compares the actual XP of adjacent routes in both directions, and speed choices match native buttons');
        const state=()=>evaluate(`(()=>{const r=${root},host=document.querySelector('#pokecatch-auto-helper').getBoundingClientRect(),e=__pcExecutionTest.engine;return{foreground:r.querySelector('#foreground-task')?.textContent,foregroundDetail:r.querySelector('#foreground-detail')?.textContent,services:r.querySelector('#background-services')?.textContent,serviceStates:Object.fromEntries([...r.querySelectorAll('#background-services [data-service]')].map(el=>[el.dataset.service,{state:el.dataset.state,text:el.textContent}])),owner:r.querySelector('#ui-owner')?.textContent,rules:r.querySelector('#parallel-rules')?.textContent,queue:r.querySelector('#start-queue')?.textContent,mini:r.querySelector('#mini-state')?.textContent,running:e.running,manual:!!e.manual,host:{left:host.left,right:host.right,top:host.top,bottom:host.bottom},card:!!r.querySelector('#execution-info'),save:localStorage.getItem('gachamon-save-v1')}})()`);
        let current=await state();assert.equal(current.card,true);assert.ok(current.host.right<=1280&&current.host.left>=0);assert.match(current.queue,/串行/);checks.push('the task card and serial queue explanation mount before automation starts');
        await evaluate(`(()=>{const e=__pcExecutionTest.engine;e.schedule=()=>{};e.settings={...e.settings,mode:'money',autoTeam:true,autoPrepare:false,raids:false,moneyBuff:false};e.running=true;e.started=Date.now();e.startMoney=fixtureState.money;e.lastProgress=Date.now();e.status='fixture active primary';e.onChange()})()`);
        current=await state();assert.match(current.foreground,/刷钱/);assert.match(current.services,/未配置|没有|暂无|未寄养|未派遣|空闲/);checks.push('a selected primary task does not invent configured background work');
        assert.match(await evaluate(`${root}.querySelector('#action').textContent`),/助手已接管/);checks.push('a running task with no recent click never displays the idle start prompt');
        await evaluate(`(()=>{const now=Date.now();fixtureState.pension.eggs=[{uid:'egg',id:25,reg:'kanto',hatchAt:now+120000}];fixtureState.under.slots=[{id:'u',bay:0,start:now-1000,end:now+180000,team:['u0','u1','u2'],mons:[{uid:'u0',id:1,level:70},{uid:'u1',id:4,level:70},{uid:'u2',id:7,level:70}]}];commitExecution()})()`);
        current=await state();assert.match(current.services,/孵|蛋/);assert.match(current.services,/地下/);assert.match(current.services,/计时|进行|孵化|派遣|归队/);assert.equal(current.serviceStates.eggs.state,'timing');assert.equal(current.serviceStates.underground.state,'timing');assert.match(current.foreground,/刷钱/);checks.push('native egg and expedition timers are shown alongside one foreground task');
        const reused=await evaluate(`(()=>{const r=${root},service=r.querySelector('[data-service="eggs"]'),table=r.querySelector('#view table');__pcExecutionTest.engine.onChange();return !!table&&table.isConnected&&service.isConnected})()`);
        assert.ok(reused,'an unchanged foreground render preserves the service rows and route table');
        await evaluate(`fixtureState.pension.eggs[0].hatchAt=Date.now()-1;fixtureState.under.slots[0].end=Date.now()-1;commitExecution()`);
        current=await state();assert.match(current.services,/待|可领|成熟|归队/);assert.ok(['ready','waiting'].includes(current.serviceStates.eggs.state));assert.ok(['ready','waiting'].includes(current.serviceStates.underground.state));assert.match(current.foreground,/刷钱/);checks.push('mature background work becomes a pending service without replacing the main goal');
        await evaluate(`fixtureState.adv.battle={steps:2,enemies:[{id:19,hp:10}]};commitExecution()`);
        current=await state();assert.equal(current.serviceStates.eggs.state,'ready');assert.match(current.serviceStates.eggs.text,/成熟蛋优先/);assert.equal(current.serviceStates.underground.state,'waiting');checks.push('mature eggs stay eligible during ordinary combat while underground collection still waits');
        await evaluate(`fixtureState.adv.battle=null;commitExecution()`);
        await evaluate(`__pcExecutionTest.engine.settings.autoTeam=false;commitExecution()`);
        current=await state();assert.equal(current.serviceStates.eggs.state,'blocked');assert.equal(current.serviceStates.underground.state,'blocked');assert.match(current.services,/手动|阵容|入队/);checks.push('a manual party with free slots explicitly blocks services that could auto-fill it');
        await evaluate(`(()=>{const e=__pcExecutionTest.engine;e.settings.autoEggs=false;e.settings.autoUnderCollect=false;e.settings.autoUnderDispatch=false;e.onChange()})()`);
        current=await state();assert.equal(current.serviceStates.eggs.state,'disabled');assert.equal(current.serviceStates.underground.state,'disabled');assert.match(current.services,/关|手动|暂停|待领|成熟/);checks.push('native maturity remains visible when automatic service is disabled');
        await evaluate(`fixtureState.adv.event={raid:true,id:35,reg:'kanto',date:'2026-11-17'};commitExecution()`);
        current=await state();assert.match(current.foreground,/团体战/);checks.push('the foreground describes the actual raid while another main goal is selected');
        await evaluate(`fixtureState.adv.event=null;__pcExecutionTest.engine.running=false;__pcExecutionTest.engine.status='fixture stopped';commitExecution()`);
        current=await state();assert.match(current.services,/待|可领|成熟|归队|手动/);assert.equal(current.running,false);checks.push('stopping the assistant does not label native background timers as stopped game systems');
        await evaluate(`__pokecatchHelper.show();${root}.querySelector('#fold').click();fixtureState.pension.eggs[0].hatchAt=Date.now()+600000;commitExecution()`);
        current=await state();assert.ok(current.mini?.length>0);assert.ok(current.host.left>=0&&current.host.right<=1280&&current.host.bottom<=900);checks.push('the folded dock remains reachable and its status can update');
        await send('Emulation.setDeviceMetricsOverride',{width:360,height:780,deviceScaleFactor:1,mobile:true});await evaluate('__pokecatchHelper.show()');
        const lookupFits=await evaluate(`(()=>{const r=${root},content=r.querySelector('.content');
            const open=page=>r.querySelector('[data-workspace="'+page+'"]').click();
            function firstScreen(selector){
                const rect=r.querySelector(selector).getBoundingClientRect(),viewport=content.getBoundingClientRect();
                return rect.width>0&&rect.height>0&&rect.top>=viewport.top&&rect.bottom<=viewport.bottom&&content.scrollWidth<=content.clientWidth+1;
            }
            open('dex');const dex=firstScreen('#dex-search');
            open('weather');const weather=firstScreen('#weather-panel [data-sky]');
            open('activity');return dex&&weather;
        })()`);
        assert.ok(lookupFits,'standalone search and weather filters fit the first mobile screen');
        const mobile=await evaluate(`(()=>{const r=${root},host=document.querySelector('#pokecatch-auto-helper').getBoundingClientRect(),card=r.querySelector('#execution-info').getBoundingClientRect(),content=r.querySelector('.content');return{host:{left:host.left,right:host.right,bottom:host.bottom},card:{left:card.left,right:card.right},width:content.clientWidth,scrollWidth:content.scrollWidth}})()`);
        assert.ok(mobile.host.left>=0&&mobile.host.right<=360&&mobile.host.bottom<=780,JSON.stringify(mobile));assert.ok(mobile.card.left>=mobile.host.left&&mobile.card.right<=mobile.host.right,JSON.stringify(mobile));assert.ok(mobile.scrollWidth<=mobile.width+1,JSON.stringify(mobile));checks.push('the task/concurrency card fits a 360-pixel viewport without horizontal overflow');
        const screenshot=await send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(dir,'execution-mobile.png'),Buffer.from(screenshot.data,'base64'));
        current=await state();assert.equal(JSON.parse(current.save).money,game.money);assert.equal(JSON.parse(current.save).mons[0].uid,'a');assert.match(current.rules,/串行|互斥/);checks.push('rules describe serialized UI operations and the display never mutates the game save');
        await evaluate(`(()=>{const e=__pcExecutionTest.engine;fixtureState.mons.push({uid:'b',id:9,level:80,reg:'kanto'});fixtureState.team=['b','a'];fixtureState.road=['a'];e.settings.autoTeam=true;e.driver.teamTask={uids:['b','a'],started:Date.now(),pending:{at:Date.now(),before:'a'}};e.driver.navigation={screen:'team',name:'队伍 / PC',attempts:2,started:Date.now(),nextAt:Date.now()+1200};commitExecution();${root}.querySelector('#decision-info').open=true})()`);
        const decision=await evaluate(`(()=>{const r=${root},card=r.querySelector('#decision-info').getBoundingClientRect();return{route:r.querySelector('#execution-route').textContent,team:r.querySelector('#execution-team').textContent,reason:r.querySelector('#execution-reason').textContent,width:r.querySelector('.content').clientWidth,scrollWidth:r.querySelector('.content').scrollWidth,left:card.left,right:card.right}})()`);
        assert.match(decision.route,/实际路线.*正在打开队伍/);assert.match(decision.team,/等待拖放存档确认.*水箭龟.*当前行进阵容.*喷火龙/);assert.ok(decision.reason);assert.ok(decision.scrollWidth<=decision.width+1);assert.ok(decision.left>=0&&decision.right<=360);checks.push('expanded mobile decisions distinguish saved PC order, pending drag confirmation and the real travelling squad');
        const decisionScreenshot=await send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(dir,'decision-mobile.png'),Buffer.from(decisionScreenshot.data,'base64'));
        await evaluate(`(()=>{const e=__pcExecutionTest.engine;e.driver.teamTask=null;e.driver.navigation=null;e.automation.state={};e.running=true;e.settings.autoTeam=true;e.settings.autoUnderDispatch=true;e.settings.autoUnderCollect=false;fixtureState.adv.chapter=48;fixtureState.adv.unlocked=60;fixtureState.travel.to=['johto','hoenn','sinnoh'];fixtureState.mons=[6,9,3,65,68,149,19,16,10,13].map((id,i)=>({uid:'idle-ui-'+i,id,level:i<6?100:20,reg:'sinnoh'}));fixtureState.team=fixtureState.mons.slice(0,6).map(mon=>mon.uid);fixtureState.road=[...fixtureState.team];fixtureState.under={day:new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Paris',year:'numeric',month:'2-digit',day:'2-digit'}).format(Date.now()),sent:0,used:{},slots:[],geodes:[0,0,0,0]};commitExecution()})()`);
        const dispatchUI=await evaluate(`(()=>{const r=${root},service=r.querySelector('[data-service="underground"]');return{enabled:r.querySelector('[data-setting="autoUnderDispatch"]').checked,state:service.dataset.state,text:service.textContent,rules:r.querySelector('#parallel-rules').textContent,width:r.querySelector('.content').clientWidth,scrollWidth:r.querySelector('.content').scrollWidth}})()`);
        assert.equal(dispatchUI.enabled,true);assert.equal(dispatchUI.state,'waiting');assert.match(dispatchUI.text,/自动派遣开.*领取关.*冒险配队|自动派遣开.*领取关.*适配冒险阵容/);assert.match(dispatchUI.rules,/空闲队员.*主队.*Buddy/);assert.ok(dispatchUI.scrollWidth<=dispatchUI.width+1);checks.push('Sinnoh background dispatch waits for adventure fitting and explains its independent settings');
        await evaluate(`(()=>{fixtureState.pension.eggs=[{uid:'odds-sp2',id:25,sp:2,hatchAt:Date.now()+600000}];fixtureState.dex={};fixtureState.buffs={};const r=${root};r.querySelector('#probability-info').open=true;r.querySelector('#decision-info').open=true;commitExecution()})()`);
        const odds=await evaluate(`(()=>{const r=${root},panel=r.querySelector('.panel').getBoundingClientRect(),content=r.querySelector('.content');return{wild:r.querySelector('#probability-wild').textContent,eggs:r.querySelector('#probability-eggs').textContent,open:r.querySelector('#probability-info').open,importDisabled:r.querySelector('#import-profile').disabled,exportPresent:!!r.querySelector('#export-profile'),inputType:r.querySelector('#profile-file').type,left:panel.left,right:panel.right,bottom:panel.bottom,width:content.clientWidth,scrollWidth:content.scrollWidth}})()`);
        assert.equal(odds.open,true);assert.match(odds.wild,/1\/2048/);assert.match(odds.eggs,/1\/16/);assert.equal(odds.importDisabled,true);assert.equal(odds.exportPresent,true);assert.equal(odds.inputType,'file');
        assert.ok(odds.left>=0&&odds.right<=360&&odds.bottom<=780,JSON.stringify(odds));assert.ok(odds.scrollWidth<=odds.width+1,JSON.stringify(odds));checks.push('expanded mobile odds show native wild 1/2048 and new sp:2 egg 1/16 while importing remains disabled during execution');
        await evaluate(`__pcExecutionTest.engine.stop('configuration review fixture');commitExecution()`);
        assert.equal(await evaluate(`${root}.querySelector('#import-profile').disabled`),false);checks.push('stopping the task re-enables configuration import without auto-starting a replacement task');
        const environment=await evaluate(`(async()=>{const e=__pcExecutionTest.engine,r=${root};e.running=true;e.started=Date.now();e.tabToken=localStorage.getItem('pokecatch-tab');e.manual=null;e.preparation=null;e.raidPreparation=null;e.driver.teamTask=null;e.driver.navigation=null;e.lastProgress=Date.now();Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});document.documentElement.setAttribute('data-pc-helper-background-at',String(Date.now()));e.onChange();const active=r.querySelector('#execution-environment').textContent;document.documentElement.setAttribute('data-pc-helper-background-at',String(Date.now()-90000));e.onChange();await e.step();e.onChange();const expired=r.querySelector('#execution-environment').textContent,status=e.status;document.documentElement.removeAttribute('data-pc-helper-background-at');delete document.hidden;e.stop('environment fixture complete');e.onChange();return{active,expired,status}})()`);
        assert.match(environment.active,/保活扩展已启用.*后台运行许可/);assert.match(environment.expired,/当前标签在后台.*等待回到游戏/);assert.match(environment.status,/后台等待/);checks.push('a fresh companion heartbeat grants background status while an expired heartbeat restores the ordinary hidden-tab wait');
        const expandedScreenshot=await send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(dir,'probability-profile-mobile.png'),Buffer.from(expandedScreenshot.data,'base64'));
        const ended=await evaluate(`(()=>{
            const e=__pcExecutionTest.engine,r=${root},s=fixtureState;
            r.querySelector('[data-workspace="tasks"]').click();
            e.settings={...e.settings,mode:'train',trainUid:'team',trainLevel:100,raids:false};
            s.mons[0].xp=0;s.money=1000;commitExecution();e.start();if(!e.running)throw Error(e.status);e.onChange();
            s.adv.paused=true;commitExecution();
            const nativePause=[r.querySelector('#run-state').textContent,r.querySelector('#mini-state').textContent,r.querySelector('#resume').classList.contains('hidden')];
            s.adv.paused=false;commitExecution();
            const resumed=r.querySelector('#run-state').textContent;
            s.money+=300;s.mons[0].xp+=120;
            localStorage.setItem('gachamon-save-v1',JSON.stringify(s));
            r.querySelector('#stop').click();
            s.money+=700;s.mons[0].xp+=400;commitExecution();
            const training=[r.querySelector('#money-value').textContent,r.querySelector('#dex-value').textContent];
            e.settings={...e.settings,mode:'item',itemId:'rare-candy'};s.stats.itemIn={'rare-candy':6};
            commitExecution();e.start();if(!e.running)throw Error(e.status);
            s.stats.itemIn['rare-candy']+=2;commitExecution();r.querySelector('#stop').click();
            s.stats.itemIn['rare-candy']+=5;commitExecution();
            return {nativePause,resumed,training,items:r.querySelector('#dex-value').textContent,money:r.querySelector('#money-value').textContent};
        })()`);
        assert.deepEqual(ended.training,['+300','120']);assert.match(ended.items,/^2\//);assert.equal(ended.money,'0');
        assert.match(ended.nativePause[0],/游戏暂停/);assert.match(ended.nativePause[1],/游戏已暂停/);assert.equal(ended.nativePause[2],true);assert.match(ended.resumed,/运行中/);
        checks.push('the full panel and minimized label reflect native pause and resume without offering the manual takeover button');
        checks.push('final wallet, trainee EXP and item gains freeze at Stop while the native game continues, and the next task gets a fresh baseline');
        const purchaseUI=await evaluate(`(()=>{
            const r=${root},q=selector=>r.querySelector(selector);
            const task=q('#task-purchase'),settings=q('#settings-purchase');
            const taskInput=task.querySelector('[data-setting="autoPurchase"]'),settingsInput=settings.querySelector('[data-setting="autoPurchase"]');
            const visible=el=>el.getClientRects().length>0;
            const boxFits=el=>{const b=el.getBoundingClientRect();return b.left>=-1&&b.right<=innerWidth+1;};
            const set=(key,n)=>{const field=q('[data-setting="'+key+'"]');field.value=n;field.dispatchEvent(new Event('change',{bubbles:true}));};
            const selectTask=mode=>{
                const button=q('[data-mode="'+mode+'"]');
                q('[data-category="'+button.dataset.group+'"]').click();
                if(!visible(button))throw Error('Task not reachable: '+mode);
                button.click();
            };
            fixtureState.money=12340;commitExecution();q('[data-workspace="tasks"]').click();
            const discoverable=['resource','progress','breed'].map(mode=>{
                selectTask(mode);
                return visible(taskInput)&&boxFits(task)&&!taskInput.closest('details:not([open])');
            });
            selectTask('money');
            const farmingHidesSwitch=!visible(taskInput);
            selectTask('resource');
            q('#purchase-edit-budget').click();
            const linked=visible(settingsInput)&&q('#budget-details').open;
            set('spendBudget','5000');set('moneyReserve','12000');set('dailySpendBudget','0');
            const settingsText=settings.querySelector('[data-purchase-status]').textContent;
            settingsInput.click();
            const disabledGlobally=!taskInput.checked&&!settingsInput.checked;
            q('[data-workspace="tasks"]').click();
            const off=task.querySelector('[data-purchase-status]').textContent;
            taskInput.click();
            const text=task.querySelector('[data-purchase-status]').textContent;
            const content=q('.content');
            return {discoverable,linked,farmingHidesSwitch,disabledGlobally,off,text,settingsText,synced:taskInput.checked&&settingsInput.checked,
                fits:boxFits(task)&&content.scrollWidth<=content.clientWidth+1};
        })()`);
        assert.deepEqual(purchaseUI.discoverable,[true,true,true]);assert.ok(purchaseUI.linked&&purchaseUI.fits&&purchaseUI.farmingHidesSwitch);
        assert.ok(purchaseUI.disabledGlobally&&purchaseUI.synced);assert.match(purchaseUI.off,/关/);
        assert.match(purchaseUI.text,/340/);assert.match(purchaseUI.settingsText,/340/);
        checks.push('the mobile task page shows the same purchase switch for resource, training preparation and breeding and links to the expanded budget');
        checks.push('task and settings switches stay synchronized and explain the spendable balance on the narrow viewport');
        const purchaseSettings=await evaluate(`(()=>{
            const e=__pcExecutionTest.engine,r=${root},prefix='pokecatch-helper:v1:',key=prefix+e.account;
            const saved=()=>JSON.parse(localStorage.getItem(key));
            const edit=(field,value,eventName)=>{
                const input=r.querySelector('[data-setting="'+field+'"]');
                input.value=value;input.dispatchEvent(new Event(eventName,{bubbles:true}));
            };
            // Use task commands and native browser events on the isolated page, with no game actions.
            e.schedule=()=>{};r.querySelector('[data-mode="resource"]').click();
            edit('spendBudget','10000000','input');
            window.dispatchEvent(new Event('pagehide'));
            const afterHide=saved().settings.spendBudget;
            edit('dailySpendBudget','3500','change');
            edit('dailySpendBudget','','change');
            const emptyLimit=saved().settings.dailySpendBudget;
            const lengthBefore=e.queue.length;
            r.querySelector('#add-job').click();
            const invalidDraft=[e.queue.length===lengthBefore,r.activeElement===r.querySelector('[data-setting="dailySpendBudget"]'),r.activeElement?.getAttribute('aria-invalid')];
            r.querySelector('#start').click();
            const blockedStart=!e.running;
            edit('dailySpendBudget','0','change');
            edit('moneyReserve','10000','change');
            edit('useBudget','20','input');
            r.querySelector('#add-job').click();
            const queued=saved().queue.at(-1).settings;
            edit('moneyReserve','12000','change');
            const lease=prefix+'lease:'+e.account;
            localStorage.setItem(lease,JSON.stringify({token:'other-fixture',expires:Date.now()+60000}));
            edit('moneyReserve','0','change');
            const rejected=[saved().settings.moneyReserve,e.settings.moneyReserve,r.querySelector('[data-setting="moneyReserve"]').value,e.status];
            r.querySelector('#start-queue').click();
            const blockedQueue=!e.running;
            localStorage.removeItem(lease);
            r.querySelector('#start-queue').click();
            if(!e.running)throw Error(e.status);
            e.manualInput();e.onChange();
            const locked=r.querySelector('[data-setting="spendBudget"]').disabled;
            const master=r.querySelector('#task-purchase [data-setting="autoPurchase"]');
            const couldTurnOff=master.checked&&!master.disabled;
            master.click();
            const offWhileRunning=!master.checked&&master.disabled;
            e.budget.used=1;window.dispatchEvent(new Event('pagehide'));
            const checkpoint=saved().resume;
            e.onChange();
            const suspendedReadOnly=!!e.suspended&&[...r.querySelectorAll('[data-setting="autoPurchase"]')].every(input=>input.disabled);
            master.click();
            window.dispatchEvent(new Event('pageshow'));
            const restored=[e.settings.moneyReserve,e.budget.used,e.running,e.queueRunning,e.settings.autoPurchase];
            r.querySelector('#stop').click();
            const persisted=saved().settings.autoPurchase;
            r.querySelector('#start-queue').click();
            const queuedAgain=e.settings.autoPurchase;
            r.querySelector('#stop').click();
            return {afterHide,emptyLimit,invalidDraft,blockedStart,blockedQueue,rejected,queued:[queued.spendBudget,queued.dailySpendBudget,queued.moneyReserve,queued.useBudget],
                checkpoint:[checkpoint.settings.spendBudget,checkpoint.settings.moneyReserve,checkpoint.budget.used],locked,restored,
                couldTurnOff,offWhileRunning,suspendedReadOnly,persisted,queuedAgain};
        })()`);
        assert.equal(purchaseSettings.afterHide,10000000);assert.equal(purchaseSettings.emptyLimit,3500);
        assert.deepEqual(purchaseSettings.invalidDraft,[true,true,'true']);assert.ok(purchaseSettings.blockedStart&&purchaseSettings.blockedQueue);
        assert.deepEqual(purchaseSettings.rejected.slice(0,3),[12000,12000,'0']);assert.match(purchaseSettings.rejected[3],/未保存/);
        assert.deepEqual(purchaseSettings.queued,[10000000,0,10000,20]);assert.deepEqual(purchaseSettings.checkpoint,[10000000,10000,1]);
        assert.equal(purchaseSettings.locked,true);assert.deepEqual(purchaseSettings.restored,[10000,1,true,true,false]);
        assert.equal(purchaseSettings.couldTurnOff,true);assert.equal(purchaseSettings.offWhileRunning,true);
        assert.equal(purchaseSettings.suspendedReadOnly,true);
        assert.equal(purchaseSettings.persisted,false);assert.equal(purchaseSettings.queuedAgain,false);
        checks.push('uncommitted mobile budget input survives pagehide, an empty daily cap preserves its prior limit, and an explicit zero saves');
        checks.push('invalid or unsaved budget drafts stay editable and block start, queue launch and enqueue until corrected or successfully saved');
        checks.push('the queue snapshots the edited budget, keeps manual-pause settings locked and resumes with the same limits and use counter');
        checks.push('the account purchase switch can be turned off while running, and queue restart and page suspension cannot turn it back on');
        console.log('PASS: '+checks.length+' execution/concurrency UI checks: '+checks.join('; '));console.log('Artifacts: '+dir);
    }finally{if(send&&socket?.readyState===WebSocket.OPEN){await send('Browser.close').catch(()=>{});socket.close();}child.kill();}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
