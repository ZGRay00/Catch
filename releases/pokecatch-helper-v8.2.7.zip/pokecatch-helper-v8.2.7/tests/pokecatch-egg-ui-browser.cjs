// Isolated nursery UI regression: synthetic saves, no native game code or account.
// All HTTP(S) is blocked; export downloads are captured inside the temporary page.
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),net=require('node:net'),assert=require('node:assert/strict');
const {spawn}=require('node:child_process'),{pathToFileURL}=require('node:url');
const H=require('../Pokecatch自动助手.user.js'),original=fs.readFileSync(path.join(__dirname,'../Pokecatch自动助手.user.js'),'utf8');
const source=original.replace('    mount();','    window.__pcNurseryTest={engine};\n    mount();');assert.notEqual(source,original);
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms)),at=Date.now();
const game={trainer:{id:'nursery-ui-browser',since:1700000000000},money:1000,mons:[{uid:'existing-shiny',id:1,level:30,reg:'kanto',shiny:true}],team:['existing-shiny'],road:['existing-shiny'],dex:{1:{caught:1,shiny:true}},stats:{hatched:500,caught:1},items:{},travel:{to:[]},
    pension:{laid:30,bx:0,egg:0,open:{eggs:4,slots:2},mons:[{mon:{uid:'parent-fire',id:6,level:50,shiny:false},candy:3},{mon:{uid:'parent-ditto',id:132,level:50,shiny:true}}],eggs:[{uid:'baseline-shiny',id:1,shiny:true,hatchAt:at-1000},{uid:'baseline-plain',id:4,shiny:false,laidAt:at-600000,hatchAt:at+600000,pa:{id:6}},{uid:'baseline-unknown',id:7,k:-1,hatchAt:at+600000}]},
    adv:{layout:H.DATA.layout,chapter:0,unlocked:8,node:0,runs:0,speed:4,badges:[],loops:[],gifts:{},deaths:{}}};
async function main(){
    const dir=fs.mkdtempSync(path.join(os.tmpdir(),'pokecatch-egg-ui-browser-'));
    const chrome=process.env.CHROME_PATH||['C:/Program Files/Google/Chrome/Application/chrome.exe','C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'].find(fs.existsSync);assert.ok(chrome);
    const server=net.createServer();await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const port=server.address().port;await new Promise(resolve=>server.close(resolve));
    const child=spawn(chrome,['--headless=new','--disable-gpu','--no-first-run',`--remote-debugging-port=${port}`,`--user-data-dir=${path.join(dir,'profile')}`,'about:blank'],{windowsHide:true,stdio:'ignore'});
    let socket,send;const checks=[];
    try{
        let pages;for(let n=0;n<80;n++){try{pages=await(await fetch(`http://127.0.0.1:${port}/json/list`)).json();if(pages.length)break;}catch{}await delay(100);}assert.ok(pages?.length);
        socket=new WebSocket(pages.find(page=>page.type==='page').webSocketDebuggerUrl);await new Promise((resolve,reject)=>{socket.onopen=resolve;socket.onerror=reject;});
        let seq=0;const pending=new Map();socket.onmessage=event=>{const message=JSON.parse(event.data),call=pending.get(message.id);if(!call)return;pending.delete(message.id);clearTimeout(call.timer);message.error?call.reject(Error(message.error.message)):call.resolve(message.result);};
        send=(method,params={})=>new Promise((resolve,reject)=>{const id=++seq,timer=setTimeout(()=>{pending.delete(id);reject(Error(method+' timed out'));},15000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}));});
        const evaluate=async expression=>{const result=await send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(result.exceptionDetails)throw Error(result.exceptionDetails.exception?.description||result.exceptionDetails.text);return result.result.value;};
        await send('Page.enable');await send('Runtime.enable');await send('Network.enable');await send('Network.setBlockedURLs',{urls:['http://*','https://*']});
        await send('Emulation.setDeviceMetricsOverride',{width:1280,height:900,deviceScaleFactor:1,mobile:false});
        const setup=`window.BUILD=${JSON.stringify(H.NURSERY_RULES.build)};if(!localStorage.getItem('nursery-fixture-initialized')){localStorage.clear();localStorage.setItem('gachamon-save-v1',${JSON.stringify(JSON.stringify(game))});localStorage.setItem('nursery-fixture-initialized','1')}localStorage.setItem('pokecatch-tab','nursery-ui-tab');window.fixtureState=JSON.parse(localStorage.getItem('gachamon-save-v1'));window.updateRequests=[];window.exportFiles=[];window.blobs={};window.GM_registerMenuCommand=()=>{};window.GM_xmlhttpRequest=request=>{updateRequests.push(request);return{abort(){request.onabort?.()}}};const create=URL.createObjectURL.bind(URL);URL.createObjectURL=blob=>{const url=create(blob);blobs[url]=blob;return url};const nativeAnchorClick=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){if(this.download){const name=this.download;blobs[this.href]?.text().then(text=>exportFiles.push({name,text}));return}return nativeAnchorClick.call(this)};window.drawNativeEggs=()=>{const root=document.querySelector('#pen-eggs');root.replaceChildren();for(const egg of fixtureState.pension.eggs){const card=document.createElement('button');card.className='pen-egg';card.dataset.egg=egg.uid;card.textContent='Native egg '+egg.uid;root.appendChild(card)}};drawNativeEggs();window.commitNursery=()=>{localStorage.setItem('gachamon-save-v1',JSON.stringify(fixtureState));drawNativeEggs();__pcNurseryTest.engine.onChange()};`;
        const html=path.join(dir,'index.html');fs.writeFileSync(html,'<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0;background:#152235;color:white;font:14px system-ui}#pen-eggs{padding:12px;display:flex;gap:12px}.pen-egg{width:160px;height:100px;background:#20324d;color:white;border:1px solid #52647b;border-radius:9px}</style><body><section id="screen-pension" class="screen active"><div id="pen-eggs"></div></section><script>'+setup+'</script><script>'+source.replace(/<\/script/gi,'<\\/script')+'</script></body>');
        const ready=async()=>{for(let n=0;n<80&&!await evaluate('!!window.__pokecatchHelper?.ready');n++)await delay(50);assert.equal(await evaluate('!!window.__pokecatchHelper?.ready'),true);};
        await send('Page.navigate',{url:pathToFileURL(html).href});await ready();
        const root="document.querySelector('#pokecatch-auto-helper').shadowRoot";
        if(process.argv.includes('--perf')){
            const result=await evaluate(`(()=>{
                const r=${root},e=__pcNurseryTest.engine,s=fixtureState;
                const results=[];
                const nav=page=>r.querySelector('[data-workspace="'+page+'"]').click();
                for(const size of [60,2400]){
                    s.mons=Array.from({length:size},(_,i)=>({uid:'fixture-'+i,id:i%493+1,level:50,reg:'kanto',shiny:false}));
                    commitNursery();
                    for(const kind of ['eggs-idle','eggs-save','switch']){
                        nav('eggs');
                        const ob=new MutationObserver(()=>{});ob.observe(r.querySelector('#nursery-info'),{subtree:true,childList:true,characterData:true});
                        let mutations=0;const times=[];
                        for(let i=0;i<45;i++){
                            if(kind==='eggs-save'){s.money++;localStorage.setItem('gachamon-save-v1',JSON.stringify(s));}
                            const start=performance.now();
                            if(kind==='switch')nav(['weather','eggs','tasks'][i%3]);else e.onChange();
                            const duration=performance.now()-start,edits=ob.takeRecords().length;
                            if(i>=5){times.push(duration);mutations+=edits;}
                        }
                        ob.disconnect();times.sort((a,b)=>a-b);
                        results.push({size,kind,p50:times[19],p95:times[37],max:times.at(-1),eggMutations:mutations});
                    }
                }
                return results;
            })()`);console.table(result);return;
        }
        await evaluate(`${root}.querySelector('[data-workspace="activity"]').click()`);
        const state=()=>evaluate(`(()=>{const r=${root},e=__pcNurseryTest.engine,marked=[...document.querySelectorAll('#pen-eggs [data-egg]')].filter(el=>getComputedStyle(el,'::after').content.includes('闪蛋')).map(el=>el.dataset.egg);return{running:e.running,account:e.account,open:!r.querySelector('#pane-eggs').hidden,summary:r.querySelector('#nursery-summary').textContent,shiny:r.querySelector('#nursery-shiny').textContent,ready:r.querySelector('#nursery-ready').textContent,native:r.querySelector('#nursery-native').textContent,observed:r.querySelector('#nursery-observed').textContent,error:r.querySelector('#nursery-error').textContent,hints:r.querySelector('#nursery-hints').checked,marked,badges:marked.length,ledger:e.nurseryMonitor.ledger.snapshot(),save:localStorage.getItem('gachamon-save-v1'),queue:JSON.stringify(e.queue)}})()`);
        const click=async selector=>{const point=await evaluate(`(()=>{const el=${root}.querySelector(${JSON.stringify(selector)});el.scrollIntoView({block:'center'});const box=el.getBoundingClientRect();return{x:box.x+box.width/2,y:box.y+box.height/2}})()`);await send('Input.dispatchMouseEvent',{type:'mousePressed',button:'left',buttons:1,clickCount:1,...point});await send('Input.dispatchMouseEvent',{type:'mouseReleased',button:'left',buttons:0,clickCount:1,...point});await delay(20);};
        let current=await state();assert.equal(current.running,false);assert.equal(current.open,false);assert.equal(current.ledger.nativeHatched,500);assert.equal(current.ledger.stats.hatched,0);assert.equal(current.ledger.stats.eggsObserved,0);assert.equal(current.ledger.current.shiny,1);assert.equal(current.ledger.current.unknown,1);assert.deepEqual(current.marked,['baseline-shiny']);assert.equal(current.badges,1);checks.push('collapsed startup separates current known shiny eggs from historical hatch counts and unknown results');
        await click('#fold');
        const redraw=await evaluate(`(()=>{const r=${root},e=__pcNurseryTest.engine,native=document.querySelector('#pen-eggs'),active=native.querySelector('.pen-egg');
            const original=e.onChange;e.onChange=()=>{throw Error('redraw depends on helper rendering')};
            try{
                native.replaceWith(native.cloneNode(false));drawNativeEggs();
                const cards=[...document.querySelectorAll('#pen-eggs .pen-egg')];cards[0].disabled=true;
                return {folded:!r.querySelector('.mini').classList.contains('hidden'),running:e.running,redrawn:cards[0]!==active,
                    text:cards.map(card=>getComputedStyle(card,'::after').content),disabled:cards[0].disabled};
            }finally{e.onChange=original;}
        })()`);
        assert.equal(redraw.folded,true);assert.equal(redraw.running,false);assert.equal(redraw.redrawn,true);assert.equal(redraw.disabled,true);
        assert.match(redraw.text[0],/✦ 闪蛋/);assert.deepEqual(redraw.text.slice(1),['none','none']);
        assert.equal((await state()).save,current.save);await click('.mini');
        checks.push('the folded idle helper marks the right card immediately after native replacement without editing the save or enabling the card');
        await click('[data-workspace="eggs"]');
        const familyGate=await evaluate(`(()=>{const s=fixtureState,r=${root},before=s.mons;
            const detail=()=>r.querySelector('#nursery-eggs').textContent;
            try{s.mons=[...before,...[1,2,3].map((id,i)=>({id,uid:'family-'+i,reg:'kanto',shiny:true,level:20}))];commitNursery();
                const full=detail();s.mons=before;commitNursery();return [full,detail()];
            }finally{s.mons=before;commitNursery();}
        })()`);
        assert.match(familyGate[0],/异色家族已满（4\/4）/);assert.doesNotMatch(familyGate[1],/异色家族已满/);
        checks.push('a mature shiny egg shows its family cap while full and clears the hint after a slot opens');
        await click('[data-workspace="eggs"]');current=await state();assert.equal(current.open,true);assert.equal(current.shiny,'1');assert.equal(current.ready,'1');assert.equal(current.native,'500');assert.ok(await evaluate(`${root}.querySelector('#nursery-next').textContent.length>0&&${root}.querySelector('#nursery-forecast').textContent.length>0&&${root}.querySelector('#nursery-scenarios').textContent.length>0`));assert.ok(await evaluate(`${root}.querySelector('#nursery-berry-only').textContent.length>0`));checks.push('opening the eggs workspace displays real incubator counters and clearly separated forecasts');
        const comparison=()=>evaluate(`(()=>{const r=${root},section=r.querySelector('#nursery-comparison');return{hidden:section.hidden,open:section.open,note:r.querySelector('#nursery-comparison-note').textContent,groups:[...section.querySelectorAll('.nursery-scenario')].map(el=>({name:el.querySelector('strong').textContent,rate:el.querySelector('.nursery-rate').textContent,hits:[...el.querySelectorAll('ol li')].map(row=>row.textContent),keys:[...el.querySelectorAll('ol code')].map(row=>row.textContent)}))}})()`);
        const ordinary=await comparison();assert.equal(ordinary.open,true);assert.deepEqual(ordinary.groups.map(({name,rate})=>[name,rate]),[['普通亲代 · 自然闪','1/512'],['普通亲代 · 喂果才闪','1/512 → 1/256']]);
        assert.ok(ordinary.groups.every(group=>group.hits.length===3&&group.hits.every(hit=>/1 号位 喷火龙.*小火龙.*k=\d+/.test(hit))));
        const eggDetail=await evaluate(`(()=>{const r=${root},bar=r.querySelector('#nursery-eggs progress');return{progress:bar.value/bar.max,eggs:r.querySelector('#nursery-eggs').textContent,parents:r.querySelector('#nursery-parents').textContent}})()`);
        assert.ok(eggDetail.progress>.49&&eggDetail.progress<.55);assert.match(eggDetail.eggs,/亲本 喷火龙/);assert.match(eggDetail.parents,/百变怪自然产蛋所需/);assert.match(eggDetail.parents,/产出 小火龙/);
        assert.ok(ordinary.groups[1].keys.every(key=>!ordinary.groups[0].keys.includes(key)));
        checks.push('ordinary parents show only the two relevant disjoint groups, and incubator and parent details use saved data');
        const beforeNative=current.save;await evaluate(`(()=>{const e=__pcNurseryTest.engine;e.schedule=()=>{};e.manual={until:Date.now()+15000};for(let i=0;i<8;i++){e.read();e.onChange()}})()`);current=await state();assert.equal(current.ledger.stats.hatched,0);assert.equal(current.ledger.stats.eggsObserved,0);assert.equal(current.save,beforeNative);assert.equal(await evaluate('updateRequests.length'),0);checks.push('stopped and manual repeated renders never count an egg again or invoke game/update actions');
        await evaluate(`fixtureState.pension.eggs=fixtureState.pension.eggs.filter(egg=>egg.uid!=='baseline-shiny');fixtureState.stats.hatched++;commitNursery()`);current=await state();assert.equal(current.ledger.stats.hatched,1);assert.equal(current.ledger.stats.shinyHatched,1);assert.equal(current.badges,0);
        assert.equal(current.shiny,'待判');assert.match(current.summary,/待判 1/);checks.push('remaining eggs with unconfirmed colour show pending in the shiny counter');
        const recent=await evaluate(`(()=>{const list=${root}.querySelector('#nursery-recent');return{count:list.children.length,shiny:!!list.querySelector('[data-shiny="true"]'),text:list.textContent}})()`);assert.equal(recent.count,1);assert.equal(recent.shiny,true);assert.match(recent.text,/已孵化.*闪光/);checks.push('a manual hatch is confirmed once while stopped and appears as a confirmed shiny in recent results');
        await evaluate(`fixtureState.pension.eggs.push({uid:'new-shiny',id:1,shiny:true,hatchAt:Date.now()-1},{uid:'new-plain',id:1,shiny:false,hatchAt:Date.now()-1});commitNursery()`);current=await state();assert.equal(current.ledger.stats.eggsObserved,2);assert.equal(current.ledger.stats.shinyObserved,1);assert.equal(current.ledger.stats.plainObserved,1);assert.deepEqual(current.marked,['new-shiny']);
        await evaluate(`fixtureState.pension.eggs=fixtureState.pension.eggs.filter(egg=>!['new-shiny','new-plain'].includes(egg.uid));fixtureState.stats.hatched+=2;commitNursery()`);current=await state();assert.equal(current.ledger.stats.hatched,3);assert.equal(current.ledger.stats.shinyHatched,2);assert.equal(current.ledger.stats.plainHatched,1);checks.push('a same-species mixed batch confirms both egg identities without relying on a new PC member');
        await evaluate(`fixtureState.pension.eggs=fixtureState.pension.eggs.filter(egg=>egg.uid!=='baseline-unknown');fixtureState.stats.hatched++;commitNursery()`);current=await state();assert.equal(current.ledger.stats.hatched,4);assert.equal(current.ledger.stats.unknownHatched,1);assert.equal(current.ledger.stats.plainHatched,1);checks.push('an unverified egg remains unknown after hatching rather than becoming an ordinary result');
        await evaluate(`fixtureState.pension.eggs.push({uid:'current-shiny',id:7,shiny:true,hatchAt:Date.now()+600000});commitNursery()`);current=await state();assert.equal(current.badges,1);const nativeWithHint=current.save;await click('#nursery-hints');current=await state();assert.equal(current.hints,false);assert.equal(current.badges,0);assert.deepEqual(current.marked,[]);assert.equal(current.save,nativeWithHint);assert.equal(await evaluate(`JSON.parse(localStorage.getItem('pokecatch-helper:v1:ui')).nurseryHints`),false);checks.push('disabling native-card hints removes only helper badges and persists the explicit preference');
        const beforeEvolution=current.ledger.stats;await evaluate(`fixtureState.mons[0].id=2;fixtureState.dex[2]={caught:1,shiny:true};fixtureState.mons.push({uid:'wild-shiny',id:25,level:30,shiny:true});fixtureState.stats.caught++;commitNursery()`);current=await state();assert.deepEqual(current.ledger.stats,beforeEvolution);checks.push('shiny evolution, dex entries and newly acquired shiny PC members do not create egg hatch observations');
        await evaluate(`fixtureState.pension.eggs=fixtureState.pension.eggs.filter(egg=>egg.uid!=='baseline-plain');commitNursery()`);current=await state();assert.equal(current.ledger.current.pendingDisappearances,1);assert.equal(current.ledger.stats.hatched,4);await send('Page.reload');await ready();current=await state();assert.equal(current.open,true);assert.equal(current.hints,false);assert.equal(current.ledger.current.pendingDisappearances,1);assert.equal(current.ledger.stats.hatched,4);
        await evaluate('fixtureState.stats.hatched++;commitNursery()');current=await state();assert.equal(current.ledger.stats.hatched,5);assert.equal(current.ledger.stats.plainHatched,2);assert.equal(current.ledger.stats.shinyHatched,2);assert.equal(current.ledger.current.pendingDisappearances,0);checks.push('refresh between egg disappearance and the later native counter write reconciles once');
        await evaluate('fixtureState.stats.hatched=2;commitNursery()');current=await state();assert.equal(current.ledger.segment.reason,'counter-rollback');assert.equal(current.ledger.stats.hatched,0);assert.equal(current.ledger.nativeHatched,2);assert.equal(current.ledger.current.shiny,1);checks.push('a native counter rollback starts a new observation segment without subtracting or inventing history');
        await evaluate(`(()=>{const e=__pcNurseryTest.engine;e.queue=[{id:'nursery-kept-task',settings:{...e.settings,mode:'money'},status:'pending'}];fixtureState.pension.eggs.push({uid:'after-rollback',id:4,shiny:false,hatchAt:Date.now()+600000});commitNursery()})()`);current=await state();assert.equal(current.ledger.stats.eggsObserved,1);const beforeReset={save:current.save,queue:current.queue};await click('#nursery-reset');current=await state();assert.equal(current.ledger.segment.reason,'manual');assert.equal(current.ledger.stats.eggsObserved,0);assert.equal(current.ledger.stats.hatched,0);assert.equal(current.ledger.nativeHatched,2);assert.equal(current.ledger.current.shiny,1);assert.equal(current.save,beforeReset.save);assert.equal(current.queue,beforeReset.queue);checks.push('clearing observations rebaselines current eggs and preserves the native save and task queue');
        await click('#nursery-export');await delay(30);const exported=await evaluate('exportFiles.at(-1)');assert.equal(exported.name,'pokecatch-egg-statistics.json');const report=JSON.parse(exported.text);assert.equal(report.format,'pokecatch-nursery-statistics');assert.equal(report.nativeHatched,2);assert.equal(report.current.shiny,1);assert.equal((await state()).save,beforeReset.save);checks.push('statistics export contains the observed segment without editing the game save');
        const nurseryText=async()=>{
            const read=()=>evaluate(`(()=>{const r=${root},text=id=>r.querySelector('#nursery-'+id).textContent;return{eggs:text('eggs'),next:text('next'),forecast:text('forecast'),basis:text('basis'),condition:text('condition'),scenarios:text('scenarios'),segment:text('segment')}})()`);
            let result=await read();
            for(let i=0;i<100&&result.next.includes('正在计算');i++){await delay(25);result=await read();}
            return result;
        };
        await evaluate("fixtureState.pension.eggs.push({uid:'numbered',id:4,k:6,hatchAt:Date.now()+10000});commitNursery()");
        const exact=await nurseryText();assert.match(exact.eggs,/存档已记录/);assert.match(exact.eggs,/按蛋序号确定/);
        const berryText=()=>evaluate(`(()=>{const r=${root},get=id=>r.querySelector('#nursery-'+id).textContent;return [get('feed'),get('berry-only'),get('eggs')]})()`);
        const chosen=H.nurseryForecast(game,{limit:50000}).firstBerryOnly;
        assert.ok(chosen&&chosen.position>1);
        await evaluate(`fixtureState.pension.laid=${chosen.k-1};commitNursery()`);await nurseryText();
        assert.match((await berryText())[1],new RegExp('等下一枚编号变成 #'+chosen.k+' 再喂'));
        await evaluate(`fixtureState.pension.laid=${chosen.k};commitNursery()`);await nurseryText();
        assert.match((await berryText())[0],/需要靛莓果才会闪.*现在可喂百变怪/);
        await evaluate('fixtureState.pension.bx=1;commitNursery()');await nurseryText();
        assert.match((await berryText())[0],/已记录待用靛莓果/);
        assert.match((await berryText())[2],/此蛋未记录靛莓果/);
        await evaluate("fixtureState.pension.eggs.find(x=>x.uid==='numbered').bx=1;fixtureState.pension.laid=30;fixtureState.pension.bx=0;commitNursery()");await nurseryText();
        assert.match((await berryText())[2],/此蛋已带靛莓果/);
        checks.push('future berry windows, feed-now advice, pending berries and individual incubating egg flags are distinct');
        assert.match(exact.next,/按当前条件预测/);assert.match(exact.basis,/规则已核对/);assert.match(exact.condition,/赠蛋占号后会重算/);
        await evaluate('fixtureState.pension.mons[0].candy=1024164;fixtureState.pension.egg=90*60000;commitNursery()');
        const counters=await nurseryText();
        assert.match(counters.condition,/存档产蛋进度 90\/240 分钟/);assert.doesNotMatch(counters.condition,/1024164|待领糖果/);
        assert.equal(await evaluate(`${root}.querySelector('#nursery-laying-progress').position`),.375);
        await evaluate('fixtureState.pension.eggGoal=180*60000;commitNursery()');
        assert.equal(await evaluate(`${root}.querySelector('#nursery-laying-progress').position`),.5);
        assert.ok(counters.segment.includes(new Date(at).getFullYear().toString()));
        checks.push('the saved laying timer is shown in minutes, independently of candy progress and the preserved observation date');
        await evaluate("window.BUILD='new-unverified';commitNursery()");
        const reference=await nurseryText();assert.match(reference.next,/预计 · 下一枚自然蛋 #\d+/);assert.match(reference.forecast,/预计.*第 \d+ 枚自然蛋/);assert.match(reference.basis,/已产蛋优先读存档标记/);
        const referenceComparison=await comparison();assert.match(referenceComparison.note,/实际抽中的亲代/);assert.equal(referenceComparison.groups.length,2);
        assert.equal((await berryText())[0],'');
        assert.match(reference.eggs,/存档已记录/);assert.match(reference.eggs,/预计(?:普通|闪光)/);assert.doesNotMatch(reference.eggs,/按蛋序号确定|旧规则|参考闪率|构建尚未核对/);
        const notice=await evaluate(`(()=>{const r=${root},tag=r.querySelector('.nursery-title #nursery-rule-notice');return {text:tag.textContent,hidden:tag.hidden,body:r.querySelector('#nursery-info').textContent}})()`);
        assert.equal(notice.text,'规则待核对 · 预测仅供参考');assert.equal(notice.hidden,false);
        assert.equal(notice.body.split(notice.text).length,2);assert.doesNotMatch(notice.body,/旧规则|构建尚未核对/);
        await send('Emulation.setDeviceMetricsOverride',{width:360,height:780,deviceScaleFactor:1,mobile:true});
        await evaluate(`${root}.querySelector('#nursery-info').scrollIntoView({block:'start'})`);
        const noticeImage=await send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(dir,'nursery-notice-mobile.png'),Buffer.from(noticeImage.data,'base64'));
        await send('Emulation.setDeviceMetricsOverride',{width:1280,height:900,deviceScaleFactor:1,mobile:false});
        assert.ok(await evaluate(`!${root}.querySelector('#nursery-rules').open&&!${root}.querySelector('#nursery-berry-plan').hidden`));
        await click('#nursery-rules > summary');assert.match((await nurseryText()).scenarios,/仅下一枚用果/);
        await click('#nursery-rules > summary');assert.equal((await nurseryText()).next,reference.next);
        await evaluate("window.BUILD='another-new-build';fixtureState.pension.laid++;commitNursery()");
        assert.notEqual((await nurseryText()).next,reference.next);
        await evaluate("fixtureState.pension.laid--;fixtureState.pension.bx={invalid:true};commitNursery()");
        const invalid=await nurseryText();assert.match(invalid.next,/靛莓果标记/);assert.equal(invalid.forecast,'');
        const invalidComparison=await comparison();assert.equal(invalidComparison.hidden,true);assert.equal(invalidComparison.groups.length,0);
        await evaluate("delete fixtureState.pension.bx;commitNursery()");
        checks.push('unknown builds show one small header notice and omit feeding advice; bad inputs clear prior predictions');
        await evaluate(`window.BUILD=${JSON.stringify(H.NURSERY_RULES.build)};delete fixtureState.pension.laid;commitNursery()`);
        const initial=await nurseryText();
        assert.equal(await evaluate(`${root}.querySelector('#nursery-rule-notice').hidden`),true);
        const firstK=await evaluate("fixtureState.stats.hatched+fixtureState.pension.eggs.length");
        assert.ok(initial.next.includes('#'+firstK+' ·'));assert.match(initial.basis,/按游戏初始化规则/);
        await evaluate("fixtureState.stats.hatched+=2;commitNursery()");
        assert.ok((await nurseryText()).next.includes('#'+(firstK+2)+' ·'));
        await evaluate("fixtureState.pension.eggs.pop();commitNursery()");
        assert.ok((await nurseryText()).next.includes('#'+(firstK+1)+' ·'));
        await evaluate("fixtureState.pension.eggs.push({uid:'numbered',id:4,k:6,hatchAt:Date.now()+10000});fixtureState.pension.laid=-1;commitNursery()");
        const odds=await nurseryText();assert.match(odds.next,/暂无法预测/);assert.match(odds.forecast,/仅可估计单枚闪率 0.195%/);assert.match(odds.eggs,/按蛋序号确定/);
        await evaluate("fixtureState.pension.bx=1;commitNursery()");
        assert.match((await nurseryText()).forecast,/0.391%/);
        await evaluate("fixtureState.pension.mons[0].mon.shiny=true;commitNursery()");
        assert.match((await nurseryText()).forecast,/12.5%/);
        await evaluate("fixtureState.pension.laid=30;fixtureState.pension.bx='invalid';commitNursery()");
        assert.match((await nurseryText()).next,/靛莓果标记/);assert.equal((await nurseryText()).forecast,'');
        await evaluate("fixtureState.pension.bx=1;commitNursery()");assert.match((await nurseryText()).next,/按当前条件预测/);
        await evaluate("fixtureState.pension.laid=30;fixtureState.pension.mons.pop();commitNursery()");
        const noParent=await nurseryText();assert.match(noParent.next,/百变怪/);assert.equal(noParent.forecast,'');
        await evaluate("fixtureState.pension.laid=30;fixtureState.pension.mons.push({mon:{uid:'ditto',id:132,level:50}});commitNursery()");
        await evaluate("fixtureState.pension.mons[0].mon.id=25;commitNursery()");
        let changed=await nurseryText();assert.match(changed.next,/皮卡丘/);assert.match(changed.next,/亲本槽 1/);
        await evaluate("fixtureState.travel.to.push('johto');fixtureState.pension.mons.reverse();commitNursery()");
        changed=await nurseryText();assert.match(changed.next,/皮丘/);assert.match(changed.next,/亲本槽 2/);
        const shinyParents=await comparison();assert.deepEqual(shinyParents.groups.map(group=>group.name),['闪光亲代 · 自然闪','闪光亲代 · 喂果才闪']);
        await evaluate("fixtureState.pension.mons.push({mon:{uid:'mixed',id:6,shiny:false}});commitNursery()");await nurseryText();
        const mixedParents=await comparison();assert.match(mixedParents.note,/实际抽中的亲代/);assert.equal(mixedParents.groups.length,4);
        const mixedKeys=mixedParents.groups.flatMap(group=>group.keys);assert.equal(mixedKeys.length,new Set(mixedKeys).size);
        for(const group of mixedParents.groups)assert.ok(group.hits.every(hit=>hit.includes(group.name.startsWith('普通')?'3 号位 喷火龙':'2 号位 皮卡丘')));
        await evaluate('fixtureState.pension.mons.pop();commitNursery()');await nurseryText();
        checks.push('saved flags, deterministic eggs, unverified projections and probability-only states carry distinct evidence and refresh with build, berry and parent changes');
        await send('Emulation.setDeviceMetricsOverride',{width:360,height:780,deviceScaleFactor:1,mobile:true});await evaluate('__pokecatchHelper.show();__pcNurseryTest.engine.onChange()');
        const layout=await evaluate(`(()=>{const r=${root},h=document.querySelector('#pokecatch-auto-helper').getBoundingClientRect(),c=r.querySelector('.content');return{left:h.left,right:h.right,top:h.top,bottom:h.bottom,width:c.clientWidth,scrollWidth:c.scrollWidth,open:!r.querySelector('#pane-eggs').hidden,taskControls:!!r.querySelector('.commandbar #start')&&!!r.querySelector('.commandbar #stop'),update:r.querySelector('#check-update').textContent,sources:[...r.querySelector('#update-source').options].map(option=>option.value)}})()`);
        assert.ok(layout.left>=0&&layout.right<=360&&layout.top>=0&&layout.bottom<=780,JSON.stringify(layout));assert.ok(layout.scrollWidth<=layout.width+1,JSON.stringify(layout));assert.equal(layout.open,true);assert.equal(layout.taskControls,true);assert.ok(layout.update);assert.deepEqual(layout.sources,['auto',...H.UPDATE_SOURCES.map(source=>source.id)]);checks.push('expanded nursery content fits 360 pixels while bottom task controls and four update sources remain intact');
        await evaluate(`${root}.querySelector('#nursery-info').scrollIntoView({block:'start'})`);const screenshot=await send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(dir,'nursery-mobile.png'),Buffer.from(screenshot.data,'base64'));
        await evaluate(`${root}.querySelector('#nursery-comparison').scrollIntoView({block:'start'})`);const groupsScreenshot=await send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(dir,'nursery-comparison-mobile.png'),Buffer.from(groupsScreenshot.data,'base64'));
        const scanStatus=await evaluate(`(()=>{
            const r=${root};let tick=performance.now();
            Object.defineProperty(performance,'now',{configurable:true,value:()=>tick+=10});
            fixtureState.pension.laid=101;commitNursery();
            const text=r.querySelector('#nursery-next').textContent;
            r.querySelector('[data-workspace="weather"]').click();
            fixtureState.pension.laid=279;commitNursery();
            delete performance.now;r.querySelector('[data-workspace="eggs"]').click();
            return text;
        })()`);
        assert.match(scanStatus,/正在计算/);
        for(let n=0;n<80&&!await evaluate(`${root}.querySelector('#nursery-next').textContent.includes('#279')`);n++)await delay(25);
        assert.match(await evaluate(`${root}.querySelector('#nursery-next').textContent`),/#279/);
        checks.push('unfinished scans yield, cancel on navigation and display only the latest egg serial');
        await click('#nursery-plan');assert.ok(await evaluate(`!${root}.querySelector('#pane-tasks').hidden && __pcNurseryTest.engine.settings.mode==='breed' && !__pcNurseryTest.engine.running`));checks.push('breeding shortcut configures the task without starting it');
        await click('[data-workspace="eggs"]');await click('#nursery-hints');
        const markedUid='egg" with ] and \\';
        let deterministicK=0;while(!H.eggOutcome(game,{k:deterministicK,sp:2}).shiny)deterministicK++;
        let ordinaryK=0;while(H.eggOutcome(game,{k:ordinaryK,sp:2}).shiny)ordinaryK++;
        await evaluate(`window.BUILD='unverified-original';fixtureState.pension.eggs=[{uid:${JSON.stringify(markedUid)},id:4,k:${deterministicK},sp:2,hatchAt:Date.now()+600000},{uid:'explicit-shiny',id:4,shiny:true,hatchAt:Date.now()+600000},{uid:'estimated-plain',id:4,k:${ordinaryK},sp:2,hatchAt:Date.now()+600000}];commitNursery();drawNativeEggs()`);
        assert.deepEqual((await state()).marked,[markedUid,'explicit-shiny']);
        assert.equal((await state()).running,false);assert.equal((await state()).ledger.current.shiny,1);
        assert.match((await nurseryText()).eggs,/预计闪光/);assert.match((await nurseryText()).eggs,/预计普通/);
        const badges=()=>evaluate(`[...document.querySelectorAll('#pen-eggs .pen-egg')].map(card=>getComputedStyle(card,'::after').content)`);
        assert.deepEqual(await badges(),['"预计闪蛋"','"✦ 闪蛋"','none']);
        assert.equal(await evaluate(`${root}.querySelector('#nursery-estimated').textContent`),'另预计 1 枚');
        await click('#fold');await evaluate('drawNativeEggs()');assert.deepEqual(await badges(),['"预计闪蛋"','"✦ 闪蛋"','none']);await click('.mini');
        await evaluate(`(()=>{window.BUILD='d0ed6b793f';const marker=document.createElement('script');marker.type='application/json';
            marker.src='/bundle/app.0a5492aada.js';document.head.append(marker);commitNursery();})()`);
        assert.equal(await evaluate(`${root}.querySelector('#nursery-rule-notice').hidden`),true);
        assert.match((await nurseryText()).eggs,/按蛋序号确定/);
        assert.deepEqual((await state()).marked,[markedUid,'explicit-shiny']);
        assert.deepEqual(await badges(),['"✦ 闪蛋"','"✦ 闪蛋"','none']);
        checks.push('unknown builds mark estimated eggs at idle without counting them as confirmed, and a verified bundle restores solid badges');
        console.log('PASS: '+checks.length+' nursery browser checks: '+checks.join('; '));console.log('Artifacts: '+dir);
    }finally{if(send&&socket?.readyState===WebSocket.OPEN){await send('Browser.close').catch(()=>{});socket.close();}child.kill();}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
