// Isolated startup/recovery regression: no account, game API or real save.
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),net=require('node:net'),assert=require('node:assert/strict');
const {spawn}=require('node:child_process'),{pathToFileURL}=require('node:url');
const source=fs.readFileSync(path.join(__dirname,'../Pokecatch自动助手.user.js'),'utf8'),delay=ms=>new Promise(r=>setTimeout(r,ms));
const chrome=process.env.CHROME_PATH||['C:/Program Files/Google/Chrome/Application/chrome.exe','C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'].find(fs.existsSync);
assert.ok(chrome,'Set CHROME_PATH to Chrome or Edge');
const taskDir=fs.mkdtempSync(path.join(os.tmpdir(),'pokecatch-startup-browser-'));
async function main(){
    const server=net.createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;await new Promise(r=>server.close(r));
    const child=spawn(chrome,['--headless=new','--disable-gpu','--no-first-run',`--remote-debugging-port=${port}`,`--user-data-dir=${path.join(taskDir,'profile')}`,'about:blank'],{windowsHide:true,stdio:'ignore'});
    let socket,send;const checks=[];
    try{
        let pages;for(let i=0;i<80;i++){try{pages=await(await fetch(`http://127.0.0.1:${port}/json/list`)).json();if(pages.length)break;}catch{}await delay(100);}assert.ok(pages?.length);
        socket=new WebSocket(pages.find(p=>p.type==='page').webSocketDebuggerUrl);await new Promise((r,j)=>{socket.onopen=r;socket.onerror=j;});let id=0;const pending=new Map();
        socket.onmessage=event=>{const message=JSON.parse(event.data);if(message.id){const waiter=pending.get(message.id);pending.delete(message.id);clearTimeout(waiter.timer);message.error?waiter.reject(Error(message.error.message)):waiter.resolve(message.result);}};
        send=(method,params={})=>new Promise((resolve,reject)=>{const seq=++id,timer=setTimeout(()=>{pending.delete(seq);reject(Error('CDP timeout: '+method));},15000);pending.set(seq,{resolve,reject,timer});socket.send(JSON.stringify({id:seq,method,params}));});
        const evaluate=async expression=>{const result=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(result.exceptionDetails)throw Error(result.exceptionDetails.exception?.description||result.exceptionDetails.text);return result.result.value;};
        await send('Runtime.enable');await send('Page.enable');await send('Emulation.setDeviceMetricsOverride',{width:1280,height:900,deviceScaleFactor:1,mobile:false});
        async function start(name,setup='',inject=true,scriptSource=source){
            const html=path.join(taskDir,name+'.html'),script=`if(performance.getEntriesByType('navigation')[0]?.type!=='reload')localStorage.clear();window.intervalCount=0;const nativeInterval=window.setInterval;window.setInterval=(...args)=>{window.intervalCount++;return nativeInterval(...args)};${setup}`;
            fs.writeFileSync(html,`<!doctype html><meta charset="utf-8"><body><script>${script}</script>${inject?`<script>${scriptSource.replace(/<\/script/gi,'<\\/script')}</script>`:''}</body>`);await send('Page.navigate',{url:pathToFileURL(html).href});
            const initialized=inject?'document.readyState!=="loading" && (typeof window.__pokecatchHelper?.ready==="boolean" || !!document.querySelector("#pokecatch-helper-recovery"))':'document.readyState==="complete"';
            for(let i=0;i<60&&!await evaluate(initialized);i++)await delay(50);
        }
        const state=()=>evaluate(`(()=>{const api=window.__pokecatchHelper,host=document.querySelector('#pokecatch-auto-helper'),r=host?.getBoundingClientRect(),root=host?.shadowRoot;return{ready:api?.ready,host:!!host,visible:!!r&&r.width>0&&r.height>0&&r.left>=0&&r.top>=0&&r.right<=innerWidth&&r.bottom<=innerHeight,folded:root?.querySelector('.panel').classList.contains('hidden'),status:root?.querySelector('#status').textContent,recovery:document.querySelector('#pokecatch-helper-recovery')?.textContent,intervals:window.intervalCount}})()`);
        await start('no-save');let result=await state();assert.equal(result.ready,true);assert.equal(result.visible,true);
        assert.deepEqual(await evaluate(`(()=>{const r=document.querySelector('#pokecatch-auto-helper').shadowRoot,tools=r.querySelector('#update-tools'),source=r.querySelector('#update-source');return{start:!!r.querySelector('.commandbar #start'),stop:!!r.querySelector('.commandbar #stop'),sourceInTools:source.closest('#update-tools')===tools,toolsHidden:tools.classList.contains('hidden'),sourceVisible:source.getClientRects().length>0}})()`),{start:true,stop:true,sourceInTools:true,toolsHidden:true,sourceVisible:false});
        checks.push('no save shows a visible helper with task controls in the command bar and unused update tools hidden');
        await start('mini-drag',`if(!localStorage.getItem('pokecatch-helper:v1:ui'))localStorage.setItem('pokecatch-helper:v1:ui',JSON.stringify({folded:true,mini:{x:10,y:32}}))`);
        const miniVisibility=()=>evaluate(`(()=>{
            const r=document.querySelector('#pokecatch-auto-helper').shadowRoot,link=r.querySelector('[data-mini-link="logs"]');
            link.hidden=false;link.textContent='停机记录';
            return [r.querySelector('#mini-extra-info').checked,r.querySelector('.mini').getClientRects().length>0,link.getClientRects().length>0];
        })()`);
        const toggleExtras=()=>evaluate(`(()=>{
            const r=document.querySelector('#pokecatch-auto-helper').shadowRoot;
            r.querySelector('.mini').click();r.querySelector('[data-workspace="settings"]').click();
            r.querySelector('#mini-extra-info').click();r.querySelector('#fold').click();
        })()`);
        assert.deepEqual(await miniVisibility(),[false,true,false]);
        await toggleExtras();assert.deepEqual(await miniVisibility(),[true,true,true]);
        await evaluate('location.reload()').catch(()=>{});
        for(let i=0;i<80&&!await evaluate('performance.getEntriesByType("navigation")[0]?.type==="reload" && !!window.__pokecatchHelper?.ready').catch(()=>false);i++)await delay(50);
        assert.deepEqual(await miniVisibility(),[true,true,true]);
        await toggleExtras();assert.deepEqual(await miniVisibility(),[false,true,false]);
        await toggleExtras();
        checks.push('legacy preferences show only the central button; optional shortcuts persist after reload and can be hidden again');
        const miniSetup=await evaluate(`(async()=>{
            const root=document.querySelector('#pokecatch-auto-helper').shadowRoot,mini=root.querySelector('.mini');
            root.querySelector('#mini-state').textContent='已停 · 弹窗等待超时，请处理后继续';
            for(const [key,label] of [['logs','停机记录'],['next','孵蛋 11月25日 09:29'],['queue','队列需处理 2']]){
                const button=root.querySelector('[data-mini-link="'+key+'"]');button.textContent=label;button.hidden=false;
            }
            await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
            const box=mini.getBoundingClientRect();return {x:box.left+box.width/2,y:box.top+box.height/2,width:innerWidth};
        })()`);
        await send('Input.dispatchMouseEvent',{type:'mouseMoved',x:miniSetup.x,y:miniSetup.y});
        await send('Input.dispatchMouseEvent',{type:'mousePressed',button:'left',buttons:1,clickCount:1,x:miniSetup.x,y:miniSetup.y});
        for(let x=miniSetup.x+12;x<miniSetup.width;x+=80)await send('Input.dispatchMouseEvent',{type:'mouseMoved',button:'left',buttons:1,x,y:miniSetup.y});
        await send('Input.dispatchMouseEvent',{type:'mouseMoved',button:'left',buttons:1,x:miniSetup.width-1,y:miniSetup.y});
        await send('Input.dispatchMouseEvent',{type:'mouseReleased',button:'left',clickCount:1,x:miniSetup.width-1,y:miniSetup.y});
        const miniGap=()=>evaluate(`innerWidth-document.querySelector('#pokecatch-auto-helper').shadowRoot.querySelector('.mini').getBoundingClientRect().right`);
        const edgeGap=await miniGap();
        assert.ok(Math.abs(edgeGap-6)<2,'Expected a 6px right margin after dragging, measured '+edgeGap+'px');
        await evaluate(`const r=document.querySelector('#pokecatch-auto-helper').shadowRoot;r.querySelector('#mini-state').textContent='待命';r.querySelectorAll('[data-mini-link]').forEach(b=>b.hidden=true)`);
        assert.ok(Math.abs(await miniGap()-6)<2,'A shorter status stays at the dragged right margin');
        checks.push('collapsed bar reaches the right edge and stays there as its content changes');
        await start('no-save-again');
        await evaluate(source);result=await state();assert.equal(result.intervals,1);assert.equal(await evaluate('document.querySelectorAll("#pokecatch-auto-helper").length'),1);checks.push('duplicate injection creates no second panel or interval');
        await evaluate('window.__pokecatchHelper.show();document.querySelector("#pokecatch-auto-helper").remove();window.__pokecatchHelper.show()');result=await state();assert.equal(result.visible,true);assert.equal(result.folded,false);checks.push('show reattaches and reveals a removed host');
        await evaluate('document.querySelector("#pokecatch-auto-helper").remove()');await delay(2700);assert.equal((await state()).host,true);checks.push('periodic render restores a removed host');
        await start('corrupt-save',`localStorage.setItem('gachamon-save-v1','{');`);result=await state();assert.equal(result.ready,true);assert.equal(result.visible,true);assert.ok(result.status);checks.push('malformed save leaves a visible status panel');
        await start('stale-marker',`window.legacyStopped=0;window.__pokecatchHelper={version:'2.11.1',stop(){legacyStopped++;}};`);result=await state();assert.equal(result.ready,true);assert.equal(result.visible,true);assert.equal(await evaluate('window.legacyStopped'),1);checks.push('a legacy marker without a host cannot suppress mounting');
        await start('failed-marker',`window.__pokecatchHelper={ready:false,show(){},stop(){}};`);
        result=await state();assert.equal(result.ready,true);assert.equal(result.visible,true);assert.equal(result.intervals,1);checks.push('a stale failed marker with a show function does not suppress mounting');
        await start('legacy-callbacks',`window.legacyHost=document.createElement('div');legacyHost.id='pokecatch-auto-helper';document.addEventListener('visibilitychange',()=>document.body.appendChild(legacyHost));window.legacyMenu=()=>{document.getElementById('pokecatch-auto-helper')?.remove();const error=document.createElement('div');error.id='pokecatch-helper-recovery';document.body.appendChild(error)};window.__pokecatchHelper={ready:false,show:legacyMenu,stop(){}};`);
        await evaluate('window.realHost=document.getElementById("pokecatch-auto-helper");document.dispatchEvent(new Event("visibilitychange"))');
        assert.equal(await evaluate('document.querySelectorAll("#pokecatch-auto-helper").length===1&&realHost.isConnected'),true);
        await evaluate('legacyMenu()');assert.equal(await evaluate('document.getElementById("pokecatch-auto-helper")===realHost&&!document.getElementById("pokecatch-helper-recovery")'),true);
        checks.push('legacy visibility and menu callbacks cannot replace a healthy recovered panel or leave a false error');
        await start('broken-restore',`window.oldStops=0;window.__pokecatchHelper={ready:true,show(){return true},stop(){oldStops++}};`);
        result=await state();assert.equal(result.ready,true);assert.equal(result.visible,true);assert.equal(await evaluate('oldStops'),1);checks.push('a legacy success return without a connected panel is retried after stopping the stale instance');
        await start('folded-offscreen',`localStorage.setItem('pokecatch-helper:v1:ui',JSON.stringify({folded:true,mini:{x:999999,y:-999999},panel:{x:-999999,y:999999}}));`);result=await state();assert.equal(result.ready,true);assert.equal(result.visible,true);assert.equal(result.folded,true);await evaluate('__pokecatchHelper.show()');result=await state();assert.equal(result.visible,true);assert.equal(result.folded,false);checks.push('saved folded/offscreen positions stay reachable and reset on show');
        await evaluate('document.querySelector("#pokecatch-auto-helper").shadowRoot.querySelector("#fold").click();window.nativeSleepKey=event=>event.stopPropagation();window.addEventListener("keydown",nativeSleepKey,true)');
        await send('Input.dispatchKeyEvent',{type:'keyDown',key:'P',code:'KeyP',modifiers:9});await send('Input.dispatchKeyEvent',{type:'keyUp',key:'P',code:'KeyP',modifiers:9});
        result=await state();assert.equal(result.visible,true);assert.equal(result.folded,false);await evaluate('window.removeEventListener("keydown",nativeSleepKey,true);delete window.nativeSleepKey');checks.push('Alt+Shift+P reveals the helper even if native window handlers stop key propagation');
        await start('malformed-ui',`localStorage.setItem('pokecatch-helper:v1:ui','[1,2,3]');`);result=await state();assert.equal(result.ready,true);assert.equal(result.visible,true);checks.push('invalid UI cache does not prevent rendering');
        await start('native-sleep-css',`window.helperMenus={};window.GM_registerMenuCommand=(name,fn)=>{helperMenus[name]=fn};window.alert=message=>window.lastHelperAlert=message;document.head.insertAdjacentHTML('beforeend','<style>html.sleeping body>:not(.sleep-fx){display:none!important}</style>');document.documentElement.classList.add('sleeping');`);
        result=await state();assert.equal(result.ready,true);assert.equal(result.visible,true);await evaluate('helperMenus["显示 / 复位助手面板"]()');result=await state();assert.equal(result.visible,true);assert.equal(result.folded,false);
        assert.equal(await evaluate('document.querySelector("#pokecatch-auto-helper").style.getPropertyPriority("display")'),'important');checks.push('the actual native sleep-mode CSS cannot hide the helper or its menu recovery');
        await evaluate('helperMenus["助手启动诊断"]()');const diagnosis=await evaluate('window.lastHelperAlert');assert.match(diagnosis,/启动阶段：已显示/);assert.match(diagnosis,/游戏休眠：是/);checks.push('the userscript menu exposes its execution phase and real computed visibility');
        await start('storage-denied',`Object.defineProperty(window,'localStorage',{configurable:true,get(){throw new DOMException('denied','SecurityError')}});`);result=await state();assert.equal(result.ready,true);assert.equal(result.visible,true);assert.match(result.status,/存储不可用/);checks.push('denied storage shows its reason through an in-memory helper');
        await start('shadow-failure',`Element.prototype.attachShadow=function(){throw Error('fixture shadow failure')};`);result=await state();assert.equal(result.ready,false);assert.match(result.recovery,/fixture shadow failure/);assert.equal(result.host,false);checks.push('mount failures produce a visible recovery notice');
        await start('late-mount-failure',`window.fixtureFailure=true;const originalInterval=window.setInterval;window.setInterval=(...args)=>{if(fixtureFailure)throw Error('fixture late failure');return originalInterval(...args)};`);
        assert.match((await state()).recovery,/fixture late failure/);
        await evaluate('window.failedHelper=window.__pokecatchHelper;window.fixtureFailure=false;');
        await evaluate(source);await evaluate('failedHelper.show();dispatchEvent(new Event("pageshow"));document.dispatchEvent(new Event("visibilitychange"));');
        result=await state();assert.equal(result.visible,true);assert.equal(result.intervals,1);assert.equal(result.recovery,undefined);
        assert.equal(await evaluate('document.querySelectorAll("#pokecatch-auto-helper").length'),1);checks.push('retry after a late mount failure owns one panel and heartbeat, and old recovery callbacks leave it live');
        await start('model-failure',`window.helperMenus={};window.GM_registerMenuCommand=(name,fn)=>{helperMenus[name]=fn};window.alert=message=>window.lastHelperAlert=message;window.Map=class{constructor(){throw Error('fixture early model failure')}};`);
        const failure=await evaluate('({text:document.querySelector("#pokecatch-helper-recovery")?.textContent,menus:Object.keys(helperMenus)})');assert.match(failure.text,/fixture early model failure/);assert.equal(failure.menus.length,2);
        await evaluate('helperMenus["助手启动诊断"]()');assert.match(await evaluate('window.lastHelperAlert'),/初始化失败[\s\S]*fixture early model failure/);checks.push('failures before mounting retain both a visible reason and the userscript diagnostic menu');
        const lifecycleSource=source.replace('    mount();','    window.__pcStartupTest={engine};\n    mount();');assert.notEqual(lifecycleSource,source);
        const lifecycleGame={trainer:{id:'startup-lifecycle'},mons:[{uid:'a',id:6,level:40}],team:['a'],road:['a'],dex:{},money:1000,stats:{},items:{},travel:{to:[]},adv:{layout:6,chapter:0,unlocked:8,node:0,runs:0,speed:4,badges:[],loops:[],gifts:{},deaths:{}}};
        const lifecycleSetup=`localStorage.setItem('gachamon-save-v1',${JSON.stringify(JSON.stringify(lifecycleGame))});localStorage.setItem('pokecatch-tab','startup-lifecycle-tab');localStorage.setItem('pokecatch-helper:v1:startup-lifecycle',JSON.stringify({settings:{mode:'money',autoPrepare:false,autoTeam:false,raids:false,moneyBuff:false},metrics:{},queue:[]}));`;
        const lifecycleState=()=>evaluate(`(()=>{const e=__pcStartupTest.engine,r=document.querySelector('#pokecatch-auto-helper').shadowRoot;return{running:e.running,suspended:!!e.suspended,manual:!!e.manual,spent:e.budget.spent,used:e.budget.used,started:e.started,queueRunning:e.queueRunning,queueIndex:e.queueIndex,ownerSame:e.automation.state.resourceTx===window.savedTransaction,prepSame:e.preparation===window.savedPreparation,resumeHidden:r.querySelector('#resume').classList.contains('hidden'),resumeText:r.querySelector('#resume').textContent,stopDisabled:r.querySelector('#stop').disabled,settingsDisabled:r.querySelector('[data-setting]').disabled}})()`);
        await start('bfcache-auto-resume',lifecycleSetup,true,lifecycleSource);
        const started=await evaluate(`(()=>{const e=__pcStartupTest.engine;e.schedule=()=>{};e.start();e.manualInput();e.budget.spent=123;e.budget.used=2;e.queueRunning=true;e.queueIndex=2;window.savedTransaction=e.automation.state.resourceTx={kind:'use',id:'exp-candy-m',at:Date.now(),stock:1,out:0};window.savedPreparation=e.preparation={phase:'train',targets:[{uid:'a',goal:50}],uids:['a'],phaseAt:Date.now(),lastGrowth:Date.now(),lastTick:Date.now()};return e.started})()`);
        await evaluate(`dispatchEvent(new PageTransitionEvent('pagehide',{persisted:true}));Object.defineProperty(document,'hidden',{configurable:true,value:true});dispatchEvent(new PageTransitionEvent('pageshow',{persisted:true}))`);
        assert.equal((await lifecycleState()).suspended,true,'a pageshow in a background tab retains its original session');
        await evaluate(`delete document.hidden;document.dispatchEvent(new Event('visibilitychange'))`);
        let life=await lifecycleState();assert.equal(life.running,true);assert.equal(life.suspended,false);assert.equal(life.manual,true);assert.equal(life.spent,123);assert.equal(life.used,2);assert.equal(life.started,started);assert.equal(life.queueRunning,true);assert.equal(life.queueIndex,2);assert.equal(life.ownerSame,true);assert.equal(life.prepSame,true);checks.push('BFCache pageshow resumes the same manual session with preparation, queue and resource budgets intact');
        await start('bfcache-explicit-resume',lifecycleSetup,true,lifecycleSource);
        await evaluate(`(()=>{const e=__pcStartupTest.engine;e.schedule=()=>{};e.start();e.settings.resumeOnReload=false;e.budget.spent=321;e.budget.used=3;dispatchEvent(new PageTransitionEvent('pagehide',{persisted:true}));dispatchEvent(new PageTransitionEvent('pageshow',{persisted:true}))})()`);
        life=await lifecycleState();assert.equal(life.running,false);assert.equal(life.suspended,true);assert.equal(life.resumeHidden,false);assert.equal(life.stopDisabled,false);assert.equal(life.settingsDisabled,true);assert.match(life.resumeText,/继续/);
        await evaluate(`document.querySelector('#pokecatch-auto-helper').shadowRoot.querySelector('#resume').click()`);life=await lifecycleState();assert.equal(life.running,true);assert.equal(life.suspended,false);assert.equal(life.spent,321);assert.equal(life.used,3);checks.push('disabled reload resume keeps the suspended task reviewable and Continue resumes it without resetting its budget');
        await evaluate(`dispatchEvent(new PageTransitionEvent('pagehide',{persisted:true}));dispatchEvent(new PageTransitionEvent('pageshow',{persisted:true}));document.querySelector('#pokecatch-auto-helper').shadowRoot.querySelector('#stop').click();dispatchEvent(new PageTransitionEvent('pageshow',{persisted:true}))`);
        life=await lifecycleState();assert.equal(life.running,false);assert.equal(life.suspended,false);assert.equal(life.manual,false);checks.push('Stop cancels a suspended BFCache task and future pageshow events cannot revive it');
        await require('./fixtures/pokecatch-native-update-browser.cjs')({start,evaluate,checks,lifecycleSetup,lifecycleSource});
        const game={trainer:{id:'isolated-startup'},mons:[{uid:'a',id:6,level:20}],team:['a'],dex:{},money:1000,stats:{},travel:{to:[]},adv:{layout:6,chapter:0,unlocked:8,node:0,runs:0,speed:4,badges:[],loops:[]}};
        await start('isolated-world',`localStorage.setItem('gachamon-save-v1',${JSON.stringify(JSON.stringify(game))});`,false);const before=await evaluate('localStorage.getItem("gachamon-save-v1")');
        const tree=await send('Page.getFrameTree'),world=await send('Page.createIsolatedWorld',{frameId:tree.frameTree.frame.id,worldName:'pokecatch-userscript-dom'});
        const isolated=await send('Runtime.evaluate',{expression:source,contextId:world.executionContextId,returnByValue:true});assert.equal(isolated.exceptionDetails,undefined);
        const isolatedState=await send('Runtime.evaluate',{expression:'({ready:window.__pokecatchHelper.ready,visible:document.getElementById("pokecatch-auto-helper").getBoundingClientRect().width>0})',contextId:world.executionContextId,returnByValue:true});
        assert.deepEqual(isolatedState.result.value,{ready:true,visible:true});assert.equal(await evaluate('typeof window.__pokecatchHelper'),'undefined');assert.equal(await evaluate('localStorage.getItem("gachamon-save-v1")'),before);checks.push('DOM-isolated execution mounts against the shared game save without relying on page globals or modifying the save');
        const another=await send('Page.createIsolatedWorld',{frameId:tree.frameTree.frame.id,worldName:'pokecatch-userscript-second'});
        const injectedAgain=await send('Runtime.evaluate',{expression:'window.GM_registerMenuCommand=(name,fn)=>(window.menus??={})[name]=fn;\n'+source,contextId:another.executionContextId,returnByValue:true});
        assert.equal(injectedAgain.exceptionDetails,undefined);
        await evaluate('document.querySelector("#pokecatch-auto-helper").shadowRoot.querySelector("#fold").click()');
        await send('Runtime.evaluate',{expression:'menus["显示 / 复位助手面板"]()',contextId:another.executionContextId});
        assert.equal(await evaluate('document.querySelectorAll("#pokecatch-auto-helper").length'),1);
        assert.equal(await evaluate('document.querySelector("#pokecatch-auto-helper").shadowRoot.querySelector(".panel").classList.contains("hidden")'),false);
        const secondApi=await send('Runtime.evaluate',{expression:'typeof window.__pokecatchHelper',contextId:another.executionContextId,returnByValue:true});
        assert.equal(secondApi.result.value,'undefined');checks.push('a second independent world reuses the live owner and its restore menu without starting another engine');
        await start('wrapped-top-window',`
            window.helperMenus={};
            window.GM_registerMenuCommand=(name,fn)=>{helperMenus[name]=fn;};
            window.alert=message=>{window.diagnostic=message;};
            window.scriptWindow=new Proxy({},{
                get(target,key){
                    if(key==='self')return scriptWindow;
                    if(Object.hasOwn(target,key))return target[key];
                    const value=window[key];
                    return typeof value==='function'?value.bind(window):value;
                }
            });
        `,false);
        assert.equal(await evaluate('scriptWindow.self===scriptWindow.top'),false);
        await evaluate('(function(window){\n'+source+'\n})(scriptWindow)');
        assert.equal(await evaluate('scriptWindow.__pokecatchHelper.ready'),true);
        assert.equal((await state()).visible,true);
        await evaluate('helperMenus["助手启动诊断"]()');
        assert.match(await evaluate('diagnostic'),/启动阶段：已显示/);
        checks.push('a wrapped top window shows the panel and working diagnostic menu even when self and top differ');
        console.log('PASS: '+checks.length+' startup/recovery checks: '+checks.join('; '));console.log('Artifacts: '+taskDir);
    }finally{if(send&&socket?.readyState===WebSocket.OPEN){await send('Browser.close').catch(()=>{});socket.close();}child.kill();}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
